# Linux-OFX
OFX Plugins for DaVinci Resolve Linux

Unzip and place ofx.bundle folders in /usr/OFX/Plugins
