# macOS-OFX
OFX Plugins for DaVinci Resolve macOS

Unzip and place ofx.bundle folders in /Library/OFX/Plugins
