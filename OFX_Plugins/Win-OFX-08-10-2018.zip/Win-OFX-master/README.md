# Win-OFX
OFX Plugins for DaVinci Resolve Windows

Unzip and place ofx.bundle folders in C:\Program Files\Common Files\OFX\Plugins
